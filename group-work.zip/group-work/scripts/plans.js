const plans = document.querySelector("#plans");
function red() {
  plans.style.display = "none";
}
loginBtn.addEventListener("click", red);

function yellow() {
  plans.style.display = "none";
}
loginBtn_1.addEventListener("click", yellow);

function green() {
  plans.style.display = "none";
}
loginBtn_2.addEventListener("click", green);
